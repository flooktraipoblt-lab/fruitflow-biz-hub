-- Phase 2: Business Operations Data Security
-- Add owner_id columns to business operations tables
ALTER TABLE public.baskets ADD COLUMN owner_id UUID;
ALTER TABLE public.mailbox_messages ADD COLUMN owner_id UUID;
ALTER TABLE public.mailbox_read_history ADD COLUMN owner_id UUID;

-- Create trigger function to set owner_id on insert for baskets
CREATE OR REPLACE FUNCTION public.set_baskets_owner_on_insert()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  IF NEW.owner_id IS NULL THEN
    NEW.owner_id = auth.uid();
  END IF;
  RETURN NEW;
END;
$$;

-- Create trigger function to set owner_id on insert for mailbox_messages
CREATE OR REPLACE FUNCTION public.set_mailbox_messages_owner_on_insert()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  IF NEW.owner_id IS NULL THEN
    NEW.owner_id = auth.uid();
  END IF;
  RETURN NEW;
END;
$$;

-- Create trigger function to set owner_id on insert for mailbox_read_history
CREATE OR REPLACE FUNCTION public.set_mailbox_read_history_owner_on_insert()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  IF NEW.owner_id IS NULL THEN
    NEW.owner_id = auth.uid();
  END IF;
  RETURN NEW;
END;
$$;

-- Create triggers
CREATE TRIGGER set_baskets_owner_trigger
  BEFORE INSERT ON public.baskets
  FOR EACH ROW
  EXECUTE FUNCTION public.set_baskets_owner_on_insert();

CREATE TRIGGER set_mailbox_messages_owner_trigger
  BEFORE INSERT ON public.mailbox_messages
  FOR EACH ROW
  EXECUTE FUNCTION public.set_mailbox_messages_owner_on_insert();

CREATE TRIGGER set_mailbox_read_history_owner_trigger
  BEFORE INSERT ON public.mailbox_read_history
  FOR EACH ROW
  EXECUTE FUNCTION public.set_mailbox_read_history_owner_on_insert();

-- Backfill existing records - assign to first admin user
DO $$
DECLARE
  admin_user_id UUID;
BEGIN
  -- Find first admin user
  SELECT ur.user_id INTO admin_user_id
  FROM public.user_roles ur
  WHERE ur.role = 'admin'
  LIMIT 1;
  
  -- If admin found, assign ownership
  IF admin_user_id IS NOT NULL THEN
    UPDATE public.baskets SET owner_id = admin_user_id WHERE owner_id IS NULL;
    UPDATE public.mailbox_messages SET owner_id = admin_user_id WHERE owner_id IS NULL;
    UPDATE public.mailbox_read_history SET owner_id = admin_user_id WHERE owner_id IS NULL;
  END IF;
END
$$;

-- Make owner_id NOT NULL after backfilling
ALTER TABLE public.baskets ALTER COLUMN owner_id SET NOT NULL;
ALTER TABLE public.mailbox_messages ALTER COLUMN owner_id SET NOT NULL;
ALTER TABLE public.mailbox_read_history ALTER COLUMN owner_id SET NOT NULL;

-- Drop old broad policies for baskets
DROP POLICY IF EXISTS "Approved or admin can select baskets" ON public.baskets;
DROP POLICY IF EXISTS "Approved or admin can insert baskets" ON public.baskets;
DROP POLICY IF EXISTS "Approved or admin can update baskets" ON public.baskets;
DROP POLICY IF EXISTS "Approved or admin can delete baskets" ON public.baskets;

-- Create new owner-based policies for baskets
CREATE POLICY "Users can view their own baskets or admins view all"
ON public.baskets
FOR SELECT
USING (owner_id = auth.uid() OR has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Users can insert their own baskets or admins"
ON public.baskets
FOR INSERT
WITH CHECK (owner_id = auth.uid() OR has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Users can update their own baskets or admins"
ON public.baskets
FOR UPDATE
USING (owner_id = auth.uid() OR has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (owner_id = auth.uid() OR has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Users can delete their own baskets or admins"
ON public.baskets
FOR DELETE
USING (owner_id = auth.uid() OR has_role(auth.uid(), 'admin'::app_role));

-- Drop old broad policies for mailbox_messages
DROP POLICY IF EXISTS "Approved or admin can select mailbox_messages" ON public.mailbox_messages;
DROP POLICY IF EXISTS "Approved or admin can insert mailbox_messages" ON public.mailbox_messages;
DROP POLICY IF EXISTS "Approved or admin can update mailbox_messages" ON public.mailbox_messages;
DROP POLICY IF EXISTS "Approved or admin can delete mailbox_messages" ON public.mailbox_messages;

-- Create new owner-based policies for mailbox_messages
CREATE POLICY "Users can view their own mailbox_messages or admins view all"
ON public.mailbox_messages
FOR SELECT
USING (owner_id = auth.uid() OR has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Users can insert their own mailbox_messages or admins"
ON public.mailbox_messages
FOR INSERT
WITH CHECK (owner_id = auth.uid() OR has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Users can update their own mailbox_messages or admins"
ON public.mailbox_messages
FOR UPDATE
USING (owner_id = auth.uid() OR has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (owner_id = auth.uid() OR has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Users can delete their own mailbox_messages or admins"
ON public.mailbox_messages
FOR DELETE
USING (owner_id = auth.uid() OR has_role(auth.uid(), 'admin'::app_role));

-- Drop old broad policies for mailbox_read_history
DROP POLICY IF EXISTS "Approved or admin can select mailbox_read_history" ON public.mailbox_read_history;
DROP POLICY IF EXISTS "Approved or admin can insert mailbox_read_history" ON public.mailbox_read_history;
DROP POLICY IF EXISTS "Approved or admin can update mailbox_read_history" ON public.mailbox_read_history;
DROP POLICY IF EXISTS "Approved or admin can delete mailbox_read_history" ON public.mailbox_read_history;

-- Create new owner-based policies for mailbox_read_history
CREATE POLICY "Users can view their own mailbox_read_history or admins view all"
ON public.mailbox_read_history
FOR SELECT
USING (owner_id = auth.uid() OR has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Users can insert their own mailbox_read_history or admins"
ON public.mailbox_read_history
FOR INSERT
WITH CHECK (owner_id = auth.uid() OR has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Users can update their own mailbox_read_history or admins"
ON public.mailbox_read_history
FOR UPDATE
USING (owner_id = auth.uid() OR has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (owner_id = auth.uid() OR has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Users can delete their own mailbox_read_history or admins"
ON public.mailbox_read_history
FOR DELETE
USING (owner_id = auth.uid() OR has_role(auth.uid(), 'admin'::app_role));